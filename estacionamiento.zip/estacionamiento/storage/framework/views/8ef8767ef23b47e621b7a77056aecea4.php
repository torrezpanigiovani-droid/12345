<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex align-items-center">
        <h3 class="card-title mb-0">Listado · <?php echo e($titulo); ?></h3>
        <button class="btn btn-primary btn-sm ml-auto" id="btn-nuevo"><i class="fas fa-plus"></i> Nuevo</button>
    </div>
    <div class="card-body">
        <table id="tabla" class="table table-bordered table-striped w-100">
            <thead>
            <tr>
                <?php $__currentLoopData = $columnas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($c['label']); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Estado</th>
                <th style="width:110px">Acciones</th>
            </tr>
            </thead>
        </table>
    </div>
</div>

<div class="modal fade" id="modal-form" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form id="form" class="modal-content" autocomplete="off">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-titulo"></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <?php $__currentLoopData = $campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group col-md-<?php echo e($c['col'] ?? 6); ?>">
                            <label for="f-<?php echo e($c['name']); ?>"><?php echo e($c['label']); ?></label>
                            <?php if($c['type'] === 'select'): ?>
                                <select class="form-control" id="f-<?php echo e($c['name']); ?>" name="<?php echo e($c['name']); ?>">
                                    <?php $__currentLoopData = $c['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($o['v']); ?>"><?php echo e($o['t']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php else: ?>
                                <input class="form-control" type="<?php echo e($c['type']); ?>" id="f-<?php echo e($c['name']); ?>" name="<?php echo e($c['name']); ?>"
                                       <?php if(isset($c['step'])): ?> step="<?php echo e($c['step']); ?>" <?php endif; ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    const campos = <?php echo json_encode($campos, 15, 512) ?>;
    const columnas = <?php echo json_encode($columnas, 15, 512) ?>;
    const URL_DATA = <?php echo json_encode(route($ruta . '.data'), 15, 512) ?>;
    const URL_STORE = <?php echo json_encode(route($ruta . '.store'), 15, 512) ?>;
    const URL_UPDATE = <?php echo json_encode(route($ruta . '.update', '__ID__'), 512) ?>;
    const URL_TOGGLE = <?php echo json_encode(route($ruta . '.toggle', '__ID__'), 512) ?>;
    let editId = null;

    const cols = columnas.map(c => ({
        data: c.data,
        defaultContent: '—',
        render: v => {
            if (v === null || v === undefined || v === '') return '—';
            if (c.type === 'ocupada') return v ? '<span class="badge badge-danger">Ocupada</span>' : '<span class="badge badge-success">Libre</span>';
            if (c.type === 'money') return money(v);
            return $('<div>').text(v).html();
        }
    }));
    cols.push({ data: 'estado', render: v => v ? '<span class="badge badge-success">Activo</span>' : '<span class="badge badge-secondary">Inactivo</span>' });
    cols.push({
        data: null, orderable: false, searchable: false,
        render: (d, t, row) => `
            <button class="btn btn-xs btn-info btn-editar" title="Editar"><i class="fas fa-edit"></i></button>
            <button class="btn btn-xs ${row.estado ? 'btn-warning' : 'btn-success'} btn-estado" title="${row.estado ? 'Desactivar' : 'Activar'}">
                <i class="fas fa-power-off"></i></button>`
    });

    const tabla = $('#tabla').DataTable({
        ajax: { url: URL_DATA, dataSrc: '' },
        columns: cols,
        order: [],
        language: { url: DT_ES },
        responsive: true
    });

    $('#btn-nuevo').on('click', function () {
        editId = null;
        $('#form')[0].reset();
        $('#modal-titulo').text('Nuevo registro');
        $('#modal-form').modal('show');
    });

    $('#tabla').on('click', '.btn-editar', function () {
        const row = tabla.row($(this).closest('tr')).data();
        editId = row.id;
        $('#form')[0].reset();
        campos.forEach(c => {
            let v = c.type === 'password' ? '' : (row[c.name] ?? '');
            $('#f-' + c.name).val(String(v));
        });
        $('#modal-titulo').text('Editar registro #' + row.id);
        $('#modal-form').modal('show');
    });

    $('#form').on('submit', function (e) {
        e.preventDefault();
        let data = $(this).serialize();
        if (editId) data += '&_method=PUT';
        $.ajax({ url: editId ? URL_UPDATE.replace('__ID__', editId) : URL_STORE, method: 'POST', data })
            .done(r => {
                $('#modal-form').modal('hide');
                Swal.fire({ icon: 'success', title: r.message, timer: 1400, showConfirmButton: false });
                tabla.ajax.reload(null, false);
            })
            .fail(mostrarErrores);
    });

    $('#tabla').on('click', '.btn-estado', function () {
        const row = tabla.row($(this).closest('tr')).data();
        Swal.fire({
            title: row.estado ? '¿Desactivar registro?' : '¿Activar registro?',
            text: 'El registro no se elimina; solo cambia su estado.',
            icon: 'question', showCancelButton: true, confirmButtonText: 'Sí', cancelButtonText: 'Cancelar'
        }).then(res => {
            if (!res.isConfirmed) return;
            $.ajax({ url: URL_TOGGLE.replace('__ID__', row.id), method: 'POST', data: { _method: 'PATCH' } })
                .done(r => { Swal.fire({ icon: 'success', title: r.message, timer: 1200, showConfirmButton: false }); tabla.ajax.reload(null, false); })
                .fail(mostrarErrores);
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\estacionamiento\resources\views/crud/index.blade.php ENDPATH**/ ?>